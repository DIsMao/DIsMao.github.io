
// put your code here...
function out(){


document.getElementById('out').style.width='60%'
document.getElementById('out').style.height='40%'
document.getElementById('out').style.top='10%'
document.getElementById('out').style.left='20%'
document.getElementById('out').style.zIndex='2'
document.getElementById('out').style.opacity='1'
document.getElementById('dot1').style.boxShadow= '0 0 10px white'
document.getElementById('dotin1').style.backgroundColor= 'white'

document.getElementById('out3').style.width='50%'
document.getElementById('out3').style.height='30%'
document.getElementById('out3').style.top='15%'
document.getElementById('out3').style.left='45%'
document.getElementById('out3').style.zIndex='1'
document.getElementById('out3').style.opacity='0.5'
document.getElementById('dot3').style.boxShadow= ''
document.getElementById('dotin3').style.backgroundColor= ''

document.getElementById('out2').style.width='50%'
document.getElementById('out2').style.height='30%'
document.getElementById('out2').style.top='15%'
document.getElementById('out2').style.left='101%'
document.getElementById('out2').style.zIndex='1'
document.getElementById('out2').style.opacity='0.5'
document.getElementById('dot2').style.boxShadow= ''
document.getElementById('dotin2').style.backgroundColor= ''
}
function out2(){


    document.getElementById('out2').style.width='60%'
    document.getElementById('out2').style.height='40%'
    document.getElementById('out2').style.top='10%'
    document.getElementById('out2').style.left='20%'
    document.getElementById('out2').style.zIndex='2'
    document.getElementById('out2').style.opacity='1'
    document.getElementById('dot2').style.boxShadow= '0 0 10px white'
    document.getElementById('dotin2').style.backgroundColor= 'white'

    document.getElementById('out3').style.width='50%'
    document.getElementById('out3').style.height='30%'
    document.getElementById('out3').style.top='15%'
    document.getElementById('out3').style.left='5%'
    document.getElementById('out3').style.zIndex='1'
    document.getElementById('out3').style.opacity='0.5'
    document.getElementById('dot3').style.boxShadow= ''
    document.getElementById('dotin3').style.backgroundColor= ''

    document.getElementById('out').style.width='50%'
    document.getElementById('out').style.height='30%'
    document.getElementById('out').style.top='15%'
    document.getElementById('out').style.left='-51%'
    document.getElementById('out').style.zIndex='1'
    document.getElementById('out').style.opacity='0.5'
    document.getElementById('dot1').style.boxShadow= ''
    document.getElementById('dotin1').style.backgroundColor= ''
    }
    function out3(){


        document.getElementById('out3').style.width='60%'
        document.getElementById('out3').style.height='40%'
        document.getElementById('out3').style.top='10%'
        document.getElementById('out3').style.left='20%'
        document.getElementById('out3').style.zIndex='2'
        document.getElementById('out3').style.opacity='1'
        document.getElementById('dot3').style.boxShadow= '0 0 10px white'
        document.getElementById('dotin3').style.backgroundColor= 'white'

        document.getElementById('out2').style.width='50%'
        document.getElementById('out2').style.height='30%'
        document.getElementById('out2').style.top='15%'
        document.getElementById('out2').style.left='45%'
        document.getElementById('out2').style.zIndex='1'
        document.getElementById('out2').style.opacity='0.5'
        document.getElementById('dot2').style.boxShadow= ''
        document.getElementById('dotin2').style.backgroundColor= ''

        document.getElementById('out').style.width='50%'
        document.getElementById('out').style.height='30%'
        document.getElementById('out').style.top='15%'
        document.getElementById('out').style.left='5%'
        document.getElementById('out').style.zIndex='1'
        document.getElementById('out').style.opacity='0.5'
        document.getElementById('dot1').style.boxShadow= ''
        document.getElementById('dotin1').style.backgroundColor= ''
        }
//var content1;
///var content2;

//content1=document.getElementById('out');
//content2=document.getElementById('out');
//content1.outerHTML='<div class="content2" onclick="out()" id="out" >2</div> ';
